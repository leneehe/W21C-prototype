/*!
 * Bootstrap-select v1.13.1 (https://developer.snapappointments.com/bootstrap-select)
 *
 * Copyright 2012-2018 SnapAppointments, LLC
 * Licensed under MIT (https://github.com/snapappointments/bootstrap-select/blob/master/LICENSE)
 */

!function(a,b){"function"==typeof define&&define.amd?define(["jquery"],function(a){return b(a)}):"object"==typeof module&&module.exports?module.exports=b(require("jquery")):b(a.jQuery)}(this,function(a){!function(a){a.fn.selectpicker.defaults={noneSelectedText:"Chưa chọn",noneResultsText:"Không có kết quả cho {0}",countSelectedText:function(a,b){return"{0} mục đã chọn"},maxOptionsText:function(a,b){return["Không thể chọn (giới hạn {n} mục)","Không thể chọn (giới hạn {n} mục)"]},selectAllText:"Chọn tất cả",deselectAllText:"Bỏ chọn",multipleSeparator:", "}}(a)});
