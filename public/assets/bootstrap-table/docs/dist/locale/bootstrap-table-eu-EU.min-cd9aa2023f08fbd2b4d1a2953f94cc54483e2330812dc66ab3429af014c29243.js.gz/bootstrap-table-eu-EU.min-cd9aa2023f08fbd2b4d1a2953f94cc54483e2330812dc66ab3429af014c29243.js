/*
* bootstrap-table - v1.12.1 - 2018-03-12
* https://github.com/wenzhixin/bootstrap-table
* Copyright (c) 2018 zhixin wen
* Licensed MIT License
*/

!function(a){"use strict";a.fn.bootstrapTable.locales["eu-EU"]={formatLoadingMessage:function(){return"Itxaron mesedez..."},formatRecordsPerPage:function(a){return a+" emaitza orriko."},formatShowingRows:function(a,b,c){return c+" erregistroetatik "+a+"etik "+b+"erakoak erakusten."},formatSearch:function(){return"Bilatu"},formatNoMatches:function(){return"Ez da emaitzarik aurkitu"},formatPaginationSwitch:function(){return"Ezkutatu/Erakutsi orrikatzea"},formatRefresh:function(){return"Eguneratu"},formatToggle:function(){return"Ezkutatu/Erakutsi"},formatColumns:function(){return"Zutabeak"},formatAllRows:function(){return"Guztiak"}},a.extend(a.fn.bootstrapTable.defaults,a.fn.bootstrapTable.locales["eu-EU"])}(jQuery);
