'use strict';

module.exports = require('./_each')();
